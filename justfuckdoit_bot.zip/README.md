# JustFuckDoIt Bot

Мотивационный Telegram-бот для Зафы.